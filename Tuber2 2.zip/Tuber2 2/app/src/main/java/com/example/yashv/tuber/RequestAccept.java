package com.example.yashv.tuber;

import android.content.Intent;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.CountDownTimer;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

import java.util.concurrent.TimeUnit;

public class RequestAccept extends AppCompatActivity {

    FirebaseDatabase database = FirebaseDatabase.getInstance();
    DatabaseReference myRef = database.getReference("User");
    GoogleSignInClient mGoogleSignInClient;
    long timeM = 0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_request_accept);
        Button btn = (Button) findViewById(R.id.btnDirections);
        Button btnT = (Button) findViewById(R.id.btnTimer);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setLogo(R.drawable.logo);
        getSupportActionBar().setDisplayUseLogoEnabled(true);
        final Button btnSA = (Button) findViewById(R.id.btnStartA);
        final Button btnES = (Button) findViewById(R.id.btnEnd);
        final TextView tv = (TextView) findViewById(R.id.txtTimer);
        final EditText ed = (EditText) findViewById(R.id.txtStuRe);
        GoogleSignInAccount acct = GoogleSignIn.getLastSignedInAccount(this);
        final String tutorId = acct.getId();
        Intent myIntent = getIntent();
        final String studentId = myIntent.getStringExtra("Student Id");
        final Button subR = (Button) findViewById(R.id.btnSbmtR);
        final Button comp = (Button) findViewById(R.id.btnEndP);

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getDirections();
            }
        });

        btnT.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startTimer();
            }
        });
        btnSA.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startTimer();
            }
        });

        btnES.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                myRef.child("Transactions").child(tutorId+studentId).child("Session Time").setValue(timeM);


                btnSA.setVisibility(View.GONE);
                btnES.setVisibility(View.GONE);
                tv.setText("DONE!");

                ed.setVisibility(View.VISIBLE);



                comp.setVisibility(View.VISIBLE);
                Toast.makeText(RequestAccept.this, "Press 'Complete' to get paid",
                        Toast.LENGTH_SHORT).show();

            }
        });

        subR.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String review = ed.getText().toString();
                myRef.child("Student").child(studentId).child("Reviews").child(tutorId).setValue(review);
                Toast.makeText(RequestAccept.this, "Your review has been submitted",
                        Toast.LENGTH_SHORT).show();
            }
        });
        comp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final String review = ed.getText().toString();

                if(!review.equals(null)) {
                    myRef.child("tutor").addValueEventListener(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                            String Name = dataSnapshot.child(tutorId).child("Name").getValue(String.class);
                            myRef.child("Student").child(studentId).child("Reviews").child(tutorId).child("Review").setValue(review);
                            myRef.child("Student").child(studentId).child("Reviews").child(tutorId).child("Name").setValue(Name);
                            Toast.makeText(RequestAccept.this, "Your review has been submitted",
                                    Toast.LENGTH_SHORT).show();


                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError databaseError) {

                        }
                    });

                    myRef.child("Transactions").child(tutorId+studentId).child("Transaction completed").setValue("true");
                    myRef.child("Transactions").child(tutorId+studentId).child("Session Time").setValue(timeM);
                    myRef.child("tutor").child(tutorId).child("Hire Request").child(studentId).removeValue();

                    Intent myIntent = new Intent(RequestAccept.this,StudentDetails.class);
                    myIntent.putExtra("Student Id",studentId);
                    startActivity(myIntent);
                }  else {

                    myRef.child("Transactions").child(tutorId+studentId).child("Transaction completed").setValue("true");
                    myRef.child("Transactions").child(tutorId+studentId).child("Session Time").setValue(timeM);
                    myRef.child("tutor").child(tutorId).child("Hire Request").child(studentId).removeValue();

                    Intent myIntent = new Intent(RequestAccept.this,StudentDetails.class);
                    myIntent.putExtra("Student Id",studentId);
                    startActivity(myIntent);
                }

            }
        });

    }


    @Override

    public void onStart() {
        super.onStart();
        final ImageView studentImg = (ImageView) findViewById(R.id.imgStudentDetailsRA);
        final TextView studentName = (TextView) findViewById(R.id.txtNameRA);
        final TextView studentEmail = (TextView) findViewById(R.id.txtEmailRA);
        final TextView studentPhone = (TextView) findViewById(R.id.txtPhoneNRA);
        final TextView studentEdu = (TextView) findViewById(R.id.txtEducRA);
        final TextView studentAge = (TextView) findViewById(R.id.txtAgeTRA);
        EditText ed = (EditText) findViewById(R.id.txtStuRe);
        ed.setVisibility(View.GONE);
        Button subR = (Button) findViewById(R.id.btnSbmtR);
        subR.setVisibility(View.GONE);
        Button comp = (Button) findViewById(R.id.btnEndP);
        comp.setVisibility(View.GONE);
        ImageButton home = (ImageButton) findViewById(R.id.btnHomeRA);
        home.setVisibility(View.GONE);
        ImageButton profile = (ImageButton) findViewById(R.id.btnProfileRA);
        profile.setVisibility(View.GONE);
        Button btnSA = (Button) findViewById(R.id.btnStartA);
        btnSA.setVisibility(View.GONE);

        Button btnES = (Button) findViewById(R.id.btnEnd);
        btnES.setVisibility(View.GONE);
        Intent myIntent = getIntent();
        final String studentId = myIntent.getStringExtra("Student Id");

        myRef.child("Student").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                String student1Name = dataSnapshot.child(studentId).child("Name").getValue(String.class);
                String student1Phone = dataSnapshot.child(studentId).child("Phone").getValue(String.class);
                String student1Age = dataSnapshot.child(studentId).child("Age").getValue(String.class);
                String student1Edu = dataSnapshot.child(studentId).child("Education").getValue(String.class);
                String student1Email = dataSnapshot.child(studentId).child("Email").getValue(String.class);
                String studentImgUrl = dataSnapshot.child(studentId).child("imgURL").getValue(String.class);



                studentName.setText(student1Name);
                studentEmail.setText(student1Email);
                studentPhone.setText(student1Phone);
                studentEdu.setText(student1Edu);
                studentAge.setText(student1Age);



                if(!studentImgUrl.equals("NO URL")) {
                    Picasso.get().load(studentImgUrl).into(studentImg);
                } else {
                    Picasso.get().load("https://picsum.photos/500/500/?random").into(studentImg);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

    }

    public void getDirections() {

        GoogleSignInAccount acct = GoogleSignIn.getLastSignedInAccount(this);
        final String tutorId = acct.getId();
        Intent myIntent = getIntent();
        final String studentId = myIntent.getStringExtra("Student Id");
        myRef.child("tutor").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                double lat = dataSnapshot.child(tutorId).child("Hire Request").child(studentId).child("Lat").getValue(Double.class);
                double longi = dataSnapshot.child(tutorId).child("Hire Request").child(studentId).child("Long").getValue(Double.class);
//                    Toast.makeText(StudentDetails.this, "Lat: "+lat+" Long: "+longi+"ID: "+tutorId,
//                            Toast.LENGTH_SHORT).show();
                Uri gmmIntentUri = Uri.parse("google.navigation:q="+lat+","+longi+"&mode=w");
                Intent mapIntent = new Intent(Intent.ACTION_VIEW, gmmIntentUri);
                mapIntent.setPackage("com.google.android.apps.maps");
                startActivity(mapIntent);

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    public void startTimer() {
        final TextView tv = (TextView) findViewById(R.id.txtTimer);
        GoogleSignInAccount acct = GoogleSignIn.getLastSignedInAccount(this);
        final String tutorId = acct.getId();
        Intent myIntent = getIntent();
        final String studentId = myIntent.getStringExtra("Student Id");
        final Button btnSA = (Button) findViewById(R.id.btnStartA);
        btnSA.setVisibility(View.GONE);
        final Button subR = (Button) findViewById(R.id.btnSbmtR);
        final EditText ed = (EditText) findViewById(R.id.txtStuRe);
        final Button btnES = (Button) findViewById(R.id.btnEnd);
        btnES.setVisibility(View.GONE);
        final MediaPlayer mp = MediaPlayer.create(this, R.raw.notification);
        final Button comp = (Button) findViewById(R.id.btnEndP);
        CountDownTimer counter = new CountDownTimer(5000, 1000){
            public void onTick(long millisUntilDone){

                timeM = timeM + 1000;
                Log.d("counter_label", "Counter text should be changed");
                tv.setText( ""+String.format("%d min, %d sec",
                        TimeUnit.MILLISECONDS.toMinutes( millisUntilDone),
                        TimeUnit.MILLISECONDS.toSeconds(millisUntilDone) -
                                TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(millisUntilDone))));
            }

            public void onFinish() {
                tv.setText("DONE! Session time = "+ TimeUnit.MILLISECONDS.toMinutes( timeM));
                btnSA.setVisibility(View.VISIBLE);
                btnES.setVisibility(View.VISIBLE);
                mp.start();




            }
        }.start();

        final Button btnT = (Button) findViewById(R.id.btnTimer);
        btnT.setVisibility(View.GONE);
    }
}
