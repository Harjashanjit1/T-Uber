package com.example.yashv.tuber;

public class Subject {
    // you can declare this as private and provide setter/getter
    public String subject;


    public Subject(String subject) {
        this.subject = subject;
    }
    public String getSubject() {
        return subject;
    }
}
