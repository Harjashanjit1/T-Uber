package com.example.yashv.tuber;

import android.view.View;

public interface CustomItemClickListener {
    public void onItemClick(View v, int position);
}
