package com.example.yashv.tuber;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class AdditionalStudentData extends AppCompatActivity implements LocationListener {

    GoogleSignInClient mGoogleSignInClient;
    FirebaseDatabase database = FirebaseDatabase.getInstance();
    DatabaseReference myRef = database.getReference("User");
    LocationManager locationManager;
    double longitude;
    double latitude;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_additional_student_data);
        Button compBtn = findViewById(R.id.btnSTComplete);

        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setLogo(R.drawable.logo);
        getSupportActionBar().setDisplayUseLogoEnabled(true);
        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestEmail()
                .build();
        mGoogleSignInClient = GoogleSignIn.getClient(this, gso);
        compBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                createStudent();
            }
        });

        if (ContextCompat.checkSelfPermission(getApplicationContext(), android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(getApplicationContext(), android.Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {

            ActivityCompat.requestPermissions(this, new String[]{android.Manifest.permission.ACCESS_FINE_LOCATION, android.Manifest.permission.ACCESS_COARSE_LOCATION}, 101);

        }
    }

    @Override
    public void onStart() {
        super.onStart();
        getLocation();
    }

    void getLocation() {
        try {
            locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
            locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 5000, 5, this);
        }
        catch(SecurityException e) {
            e.printStackTrace();
        }
    }


    @Override
    public void onLocationChanged(Location location) {
        latitude = location.getLatitude();
        longitude = location.getLongitude();
        Toast.makeText(AdditionalStudentData.this, "Long: "+longitude,
                Toast.LENGTH_SHORT).show();

//        try {
//            Geocoder geocoder = new Geocoder(this, Locale.getDefault());
//            List<Address> addresses = geocoder.getFromLocation(location.getLatitude(), location.getLongitude(), 1);
//            locationText.setText(locationText.getText() + "\n"+addresses.get(0).getAddressLine(0)+", "+
//                    addresses.get(0).getAddressLine(1)+", "+addresses.get(0).getAddressLine(2));
//        }catch(Exception e)
//        {
//
//        }

    }

    @Override
    public void onProviderDisabled(String provider) {
        Toast.makeText(AdditionalStudentData.this, "Please Enable GPS and Internet", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {

    }

    @Override
    public void onProviderEnabled(String provider) {

    }



    public void createStudent() {

        GoogleSignInAccount acct = GoogleSignIn.getLastSignedInAccount(this);

        try {
            String Name = acct.getDisplayName();
            String Email = acct.getEmail();
            String id = acct.getId();
            String token = acct.getIdToken();
            String rqApproved = "false";
            String imgURL = acct.getPhotoUrl().toString();
            EditText ed = findViewById(R.id.txtPhone);
            String phone = ed.getText().toString();
            EditText edE = findViewById(R.id.txtSTEducation);
            String Education = edE.getText().toString();
            EditText edA = findViewById(R.id.txtSTAge);
            String age = edA.getText().toString();




            myRef.child("Student").child(id).child("Name").setValue(Name);
            myRef.child("Student").child(id).child("Phone").setValue(phone);
            myRef.child("Student").child(id).child("Age").setValue(age);
            myRef.child("Student").child(id).child("Education").setValue(Education);
            myRef.child("Student").child(id).child("Email").setValue(Email);
            myRef.child("Student").child(id).child("Request Approved").setValue(rqApproved);
            myRef.child("Student").child(id).child("student").setValue("Student");
            myRef.child("Student").child(id).child("imgURL").setValue(imgURL);


            Intent newIntent = new Intent(AdditionalStudentData.this, StudentHome.class);
            startActivity(newIntent);
        } catch(NullPointerException e){
            String Email = acct.getEmail();
            String id = acct.getId();
            String rqApproved = "false";
            EditText edN = findViewById(R.id.txtSTName);
            String Name2 = edN.getText().toString();
            EditText ed = findViewById(R.id.txtPhone);
            String phone = ed.getText().toString();
            EditText edE = findViewById(R.id.txtSTEducation);
            String Education = edE.getText().toString();
            EditText edA = findViewById(R.id.txtSTAge);
            String age = edA.getText().toString();
            myRef.child("Student").child(id).child("Name").setValue(Name2);
            myRef.child("Student").child(id).child("Phone").setValue(phone);
            myRef.child("Student").child(id).child("Age").setValue(age);
            myRef.child("Student").child(id).child("Education").setValue(Education);
            myRef.child("Student").child(id).child("imgURL").setValue("NO URL");
            myRef.child("Student").child(id).child("Email").setValue(Email);
            myRef.child("Student").child(id).child("Request Approved").setValue(rqApproved);
            myRef.child("Student").child(id).child("student").setValue("Student");
            Intent newIntent = new Intent(AdditionalStudentData.this, StudentHome.class);
            startActivity(newIntent);
        }






    }
}
