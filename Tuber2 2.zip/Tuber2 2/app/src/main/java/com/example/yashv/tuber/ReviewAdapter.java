package com.example.yashv.tuber;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.List;

public class ReviewAdapter extends RecyclerView.Adapter<ReviewAdapter.MyViewHolder> {

    List<Review> subjectList;
    Context mContext;
    CustomItemClickListener listener;

    public class MyViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

        public TextView txtName;
        public TextView txtReview;

        public MyViewHolder(View view) {
            super(view);

            txtName = (TextView) view.findViewById(R.id.txtNameReview);
            txtReview = (TextView) view.findViewById(R.id.txtTutorReview);
            view.setOnClickListener(this);


            Log.d("MyViewHolder", "id"); // look at the console output
        }
        @Override
        public void onClick(View v) {
            listener.onItemClick(v, this.getAdapterPosition());
        }


    }

    public ReviewAdapter(List<Review> subjectList) {
        this.subjectList = subjectList;
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.rating_layout, parent, false);
        final MyViewHolder mViewHolder = new MyViewHolder(itemView);
        itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                listener.onItemClick(v, mViewHolder.getAdapterPosition());
            }
        });
        return new MyViewHolder(itemView);
    }
    public void onBindViewHolder(MyViewHolder holder, int position) {
        Review emp = subjectList.get(position);

        holder.txtName.setText(emp.name);
        holder.txtReview.setText(emp.review);




    }
    @Override
    public int getItemCount() {
        return subjectList.size();
    }
    public ReviewAdapter(Context mContext, List<Review> subjectList, CustomItemClickListener listener) {
        this.subjectList = subjectList;
        this.mContext = mContext;
        this.listener = listener;
    }
}
