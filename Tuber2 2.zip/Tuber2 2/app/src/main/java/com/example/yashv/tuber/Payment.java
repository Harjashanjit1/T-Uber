package com.example.yashv.tuber;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class Payment extends AppCompatActivity implements LocationListener {

    FirebaseDatabase database = FirebaseDatabase.getInstance();
    DatabaseReference myRef = database.getReference("User");
    GoogleSignInClient mGoogleSignInClient;
    double longitude;
    double latitude;
    LocationManager locationManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment);

        if (ContextCompat.checkSelfPermission(getApplicationContext(), android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(getApplicationContext(), android.Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {

            ActivityCompat.requestPermissions(this, new String[]{android.Manifest.permission.ACCESS_FINE_LOCATION, android.Manifest.permission.ACCESS_COARSE_LOCATION}, 101);

        }

        getLocation();







    }



    void getLocation() {
        try {
            locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
            locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 5000, 5, this);
            Button payment = (Button) findViewById(R.id.btnPay);

            payment.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {


                    hireFunction();

                }
            });


        }
        catch(SecurityException e) {
            e.printStackTrace();
            Button payment = (Button) findViewById(R.id.btnPay);

            payment.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {


                    hireFunction();

                }
            });

        }
    }

    @Override
    public void onLocationChanged(Location location) {
        latitude = location.getLatitude();
        longitude = location.getLongitude();





//        try {
//            Geocoder geocoder = new Geocoder(this, Locale.getDefault());
//            List<Address> addresses = geocoder.getFromLocation(location.getLatitude(), location.getLongitude(), 1);
//            locationText.setText(locationText.getText() + "\n"+addresses.get(0).getAddressLine(0)+", "+
//                    addresses.get(0).getAddressLine(1)+", "+addresses.get(0).getAddressLine(2));
//        }catch(Exception e)
//        {
//
//        }

    }

    @Override
    public void onProviderDisabled(String provider) {
        Toast.makeText(Payment.this, "Please Enable GPS and Internet", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {

    }

    @Override
    public void onProviderEnabled(String provider) {

    }


    public void hireFunction() {


        final Intent myIntent = getIntent();
        final String tutorId = myIntent.getStringExtra("Tutor Id");

        final GoogleSignInAccount acct = GoogleSignIn.getLastSignedInAccount(this);


        try {
            String studentId = acct.getId();
            String studentName = acct.getDisplayName();
            String studentEmail = acct.getEmail();
            String studentImg = acct.getPhotoUrl().toString();
            double lati = myIntent.getDoubleExtra("Lat",0.00);
            double longi = myIntent.getDoubleExtra("Long",0.00);




            myRef.child("tutor").child(tutorId).child("Hire Request").child(studentId).child("Name").setValue(studentName);
            myRef.child("tutor").child(tutorId).child("Hire Request").child(studentId).child("imgURL").setValue(studentImg);

            if(longi==0.00&&lati==0.00) {
                myRef.child("tutor").child(tutorId).child("Hire Request").child(studentId).child("Long").setValue(longitude);
                myRef.child("tutor").child(tutorId).child("Hire Request").child(studentId).child("Lat").setValue(latitude);
            } else {
                myRef.child("tutor").child(tutorId).child("Hire Request").child(studentId).child("Long").setValue(longi);
                myRef.child("tutor").child(tutorId).child("Hire Request").child(studentId).child("Lat").setValue(lati);
            }
            myRef.child("tutor").child(tutorId).child("Hire Request").child(studentId).child("Long").setValue(longitude);
            myRef.child("tutor").child(tutorId).child("Hire Request").child(studentId).child("Lat").setValue(latitude);
            myRef.child("tutor").child(tutorId).child("Hire Request").child(studentId).child("Email").setValue(studentEmail);
            Toast.makeText(Payment.this, "Your request been sent",
                    Toast.LENGTH_SHORT).show();
            Intent newIntent = new Intent(Payment.this, StudentHome.class);
            startActivity(newIntent);


        }catch (NullPointerException e) {
            String studentId = acct.getId();
            String studentEmail = acct.getEmail();
            double lati = myIntent.getDoubleExtra("Lat",0.00);
            double longi = myIntent.getDoubleExtra("Long",0.00);


            myRef.child("tutor").child(tutorId).child("Hire Request").child(studentId).child("Name").setValue(studentEmail);
            myRef.child("tutor").child(tutorId).child("Hire Request").child(studentId).child("imgURL").setValue("NO URL");
            myRef.child("tutor").child(tutorId).child("Hire Request").child(studentId).child("Email").setValue(studentEmail);
            myRef.child("tutor").child(tutorId).child("Hire Request").child(studentId).child("Long").setValue(longitude);
            myRef.child("tutor").child(tutorId).child("Hire Request").child(studentId).child("Lat").setValue(latitude);
            Toast.makeText(Payment.this, "Your request been sent",
                    Toast.LENGTH_SHORT).show();
            Intent newIntent = new Intent(Payment.this, StudentHome.class);
            startActivity(newIntent);


        }
    }
}
