package com.example.yashv.tuber;

import android.content.Intent;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

public class TutorAccount extends AppCompatActivity {

    GoogleSignInClient mGoogleSignInClient;
    FirebaseDatabase database = FirebaseDatabase.getInstance();
    DatabaseReference myRef = database.getReference("User");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tutor_account);
        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestEmail()
                .build();
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setLogo(R.drawable.logo);
        getSupportActionBar().setDisplayUseLogoEnabled(true);
        mGoogleSignInClient = GoogleSignIn.getClient(this, gso);
        final ImageView profilePic = (ImageView) findViewById(R.id.imgTutorProfile);
        final TextView name = (TextView) findViewById(R.id.txtTutorAccount);
        final TextView email = (TextView) findViewById(R.id.txtTutorEmail);
        GoogleSignInAccount acct = GoogleSignIn.getLastSignedInAccount(this);

            String id = acct.getId();
            myRef.child("tutor").child(id).addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    if(!dataSnapshot.child("imgURL").getValue(String.class).equals("NO URL")) {
                        Picasso.get().load(dataSnapshot.child("imgURL").getValue(String.class)).into(profilePic);
                    } else {
                        Picasso.get().load("https://picsum.photos/500/500/?random").into(profilePic);
                    }

                    if(!dataSnapshot.child("Name").getValue(String.class).equals(dataSnapshot.child("Email").getValue(String.class))) {
                        name.setText(dataSnapshot.child("Name").getValue(String.class));
                    } else {
                        name.setVisibility(View.GONE);
                    }
                    email.setText(dataSnapshot.child("Email").getValue(String.class));
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            });


        clicksHandler();
    }

    public void clicksHandler ()
    {
        ImageButton home = (ImageButton) findViewById(R.id.btnHomeTAccount);
        Button delete = (Button) findViewById(R.id.btnTADelete);
        Button logOut = (Button) findViewById(R.id.btnTALogout);
        Button switchA = (Button) findViewById(R.id.btnTASwitch);
        ImageButton profile = (ImageButton) findViewById(R.id.btnProfileTAccount);
        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent myIntent = new Intent(TutorAccount.this, TutorHome.class);
                startActivity(myIntent);
            }
        });
        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                revokeAccess();
            }
        });

        logOut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                signOut();
            }
        });
        switchA.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                switchAccount();
            }
        });
        profile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent myIntent = getIntent();
                finish();
                startActivity(myIntent);
            }
        });

    }

    private void revokeAccess() {
//         Firebase sign out
//        mAuth.signOut();

//        Delete data from firebase
        GoogleSignInAccount acct = GoogleSignIn.getLastSignedInAccount(this);

        final String id = acct.getId();


        // Google revoke access
        mGoogleSignInClient.revokeAccess().addOnCompleteListener(this,
                new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        myRef.child("tutor").child(id).removeValue();
                        Intent newIntent = new Intent(TutorAccount.this, MainActivity.class);
                        startActivity(newIntent);
                    }
                });
    }

    private void signOut() {
        // Firebase sign out
//        mAuth.signOut();

        // Google sign out
        mGoogleSignInClient.signOut().addOnCompleteListener(this,
                new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        Intent newIntent = new Intent(TutorAccount.this, MainActivity.class);
                        startActivity(newIntent);
                    }
                });
    }

    private void switchAccount() {
        GoogleSignInAccount acct = GoogleSignIn.getLastSignedInAccount(this);
        final String id = acct.getId();

        myRef.child("Student").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if(dataSnapshot.hasChild(id)) {
                    Intent myIntent = new Intent(TutorAccount.this,StudentHome.class);
                    startActivity(myIntent);
                }
                else {
                    Intent myIntent = new Intent(TutorAccount.this,StudentOrTutor.class);
                    startActivity(myIntent);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }
}
