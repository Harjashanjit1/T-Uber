package com.example.yashv.tuber;

import android.app.ListActivity;
import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.CardView;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.SearchView;
import android.util.TypedValue;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class StudentHome extends AppCompatActivity  {
    private RecyclerView recyclerView;
    private MyAdapter sAdapter;           // customize class
    private List<Subject> sList = new ArrayList<>();
    FirebaseDatabase database = FirebaseDatabase.getInstance();
    DatabaseReference myRef = database.getReference("User");
    GoogleSignInClient mGoogleSignInClient;
    Subject s;
    String query;






    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_home);
        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestEmail()
                .build();
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setLogo(R.drawable.logo);
        getSupportActionBar().setDisplayUseLogoEnabled(true);
        mGoogleSignInClient = GoogleSignIn.getClient(this, gso);
        final EditText et = (EditText) findViewById(R.id.txtSrch);
        ImageButton btnSrch = (ImageButton) findViewById(R.id.btnSrch);
        btnSrch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                query = et.getText().toString();
                srchData(query);
            }
        });
        ImageButton btnHome = (ImageButton) findViewById(R.id.btnHome);
        btnHome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent myIntent = getIntent();
                finish();
                startActivity(myIntent);
            }
        });
        ImageButton btnProfile = (ImageButton) findViewById(R.id.btnProfile);
        btnProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent newIntent = new Intent(StudentHome.this,StudentAccount.class);
                startActivity(newIntent);
            }
        });
        ImageButton btnAllTutors = (ImageButton) findViewById(R.id.btnAllStudentHome);
        btnAllTutors.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent newIntent = new Intent(StudentHome.this,AllAvailableTutors.class);
                startActivity(newIntent);
            }
        });







        }

    @Override
    public void onStart() {
        super.onStart();


        onLoad();


    }
        public void onLoad() {

            recyclerView = (RecyclerView) findViewById(R.id.rv);
//            sAdapter = new MyAdapter(sList);
            RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getApplicationContext());
            recyclerView.setLayoutManager(mLayoutManager);
            sAdapter = new MyAdapter(this,sList,new CustomItemClickListener() {
                @Override
                public void onItemClick(View v, int position) {

                    // do what ever you want to do with it
                    String subject = sList.get(position).getSubject();
                    Intent myIntent = new Intent(StudentHome.this,AvailableTutor.class);
                    myIntent.putExtra("Subject",subject);
                    startActivity(myIntent);
                    Toast.makeText(StudentHome.this, subject,
                            Toast.LENGTH_SHORT).show();

                }
            });
            recyclerView.setAdapter(sAdapter);
            getTheData();
        }




    private void getTheData() {


        myRef.child("Subject").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for(DataSnapshot newSnap : dataSnapshot.getChildren()) {

                    s = new Subject(newSnap.getValue(String.class));
                    sList.add(s);
                }
                sAdapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });




    }
    public void srchData(final String query) {
        RecyclerView recycler2View;
        final MyAdapter s2Adapter;           // customize class
        final List<Subject> s2List = new ArrayList<>();
        recycler2View = (RecyclerView) findViewById(R.id.rv);
//        s2Adapter = new MyAdapter(s2List);
        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getApplicationContext());
        recycler2View.setLayoutManager(mLayoutManager);
        s2Adapter = new MyAdapter(this,s2List,new CustomItemClickListener() {
            @Override
            public void onItemClick(View v, int position) {

                // do what ever you want to do with it
                String subject = sList.get(position).getSubject();
                Intent myIntent = new Intent(StudentHome.this,AvailableTutor.class);
                myIntent.putExtra("Subject",query);
                startActivity(myIntent);
            }
        });
        recycler2View.setAdapter(s2Adapter);
        myRef.child("Subject").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for(DataSnapshot newSnap : dataSnapshot.getChildren()) {
                    if(newSnap.getValue(String.class).equals(query)) {
                        s = new Subject(newSnap.getValue(String.class));
                        s2List.add(s);
                }

                }
                s2Adapter.notifyDataSetChanged();

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }


}
