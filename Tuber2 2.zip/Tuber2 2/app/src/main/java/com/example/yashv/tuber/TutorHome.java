package com.example.yashv.tuber;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class TutorHome extends AppCompatActivity {
    GoogleSignInClient mGoogleSignInClient;
    FirebaseDatabase database = FirebaseDatabase.getInstance();
    DatabaseReference myRef = database.getReference("User");
    Tutor t;
    String query;

    private RecyclerView recyclerView;
    private TutorAdapter tAdapter;           // customize class
    private List<Tutor> tList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tutor_home);

        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestEmail()
                .build();
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setLogo(R.drawable.logo);
        getSupportActionBar().setDisplayUseLogoEnabled(true);
        mGoogleSignInClient = GoogleSignIn.getClient(this, gso);

        final EditText et = (EditText) findViewById(R.id.txtSrchTutorHome);
        ImageButton btnSrch = (ImageButton) findViewById(R.id.btnSrchTutorHome);
        btnSrch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                query = et.getText().toString();
                srchData(query);
            }
        });
        ImageButton btnHome = (ImageButton) findViewById(R.id.btnTutorHome);
        btnHome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent myIntent = getIntent();
                finish();
                startActivity(myIntent);
            }
        });
        ImageButton profile = (ImageButton) findViewById(R.id.btnTutorProfile);
        profile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent myIntent = new Intent(TutorHome.this, TutorAccount.class);
                startActivity(myIntent);
            }
        });

    }

    @Override
    public void onStart() {
        super.onStart();
        GoogleSignInAccount acct = GoogleSignIn.getLastSignedInAccount(this);
        String id = acct.getId();
        myRef.child("tutor").child(id).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if(dataSnapshot.hasChild("Hire Request")) {
                    onLoad();
                } else {
                    Toast.makeText(TutorHome.this, "There is no Hire request yet, We will notify you as soo as you recieve a request",
                            Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });





    }

    public void onLoad() {

        GoogleSignInAccount acct = GoogleSignIn.getLastSignedInAccount(this);
        final String tutorId = acct.getId();
        recyclerView = (RecyclerView) findViewById(R.id.rvTutorHome);
//            sAdapter = new MyAdapter(sList);
        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getApplicationContext());
        recyclerView.setLayoutManager(mLayoutManager);
        tAdapter = new TutorAdapter(this,tList,new CustomItemClickListener() {
            @Override
            public void onItemClick(View v, int position) {

                // do what ever you want to do with it

                final String email = tList.get(position).getSubject();
                final String name = tList.get(position).getName();
                final String id = tList.get(position).getId();

                myRef.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        if(dataSnapshot.hasChild("Transactions")) {
                            if(dataSnapshot.child("Transactions").hasChild(tutorId+id)) {

                                if(dataSnapshot.child("Transactions").child(tutorId+id).hasChild("Transaction completed")) {

                                    if(dataSnapshot.child("Transactions").child(tutorId+id).child("Transaction completed").getValue(String.class).equals("true")) {
                                        Intent myIntent = new Intent(TutorHome.this, StudentDetails.class);
                                        myIntent.putExtra("Student Id", id);
                                        myIntent.putExtra("Student Name", name);
                                        myIntent.putExtra("Student Email", email);
                                        startActivity(myIntent);
                                    } else {
                                        Intent myIntent = new Intent(TutorHome.this, RequestAccept.class);
                                        myIntent.putExtra("Student Id", id);
                                        myIntent.putExtra("Student Name", name);
                                        myIntent.putExtra("Student Email", email);
                                        startActivity(myIntent);
                                    }
                                } else {
                                    Intent myIntent = new Intent(TutorHome.this, RequestAccept.class);
                                    myIntent.putExtra("Student Id", id);
                                    myIntent.putExtra("Student Name", name);
                                    myIntent.putExtra("Student Email", email);
                                    startActivity(myIntent);
                                }
                            } else {
                                Intent myIntent = new Intent(TutorHome.this,StudentDetails.class);
                                myIntent.putExtra("Student Id",id);
                                myIntent.putExtra("Student Name",name);
                                myIntent.putExtra("Student Email",email);
                                startActivity(myIntent);
                            }
                        } else {
                            Intent myIntent = new Intent(TutorHome.this,StudentDetails.class);
                            myIntent.putExtra("Student Id",id);
                            myIntent.putExtra("Student Name",name);
                            myIntent.putExtra("Student Email",email);
                            startActivity(myIntent);
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });

            }
        });
        recyclerView.setAdapter(tAdapter);
        getTheData();
    }

    public  void  getTheData() {

        GoogleSignInAccount acct = GoogleSignIn.getLastSignedInAccount(this);
        String id = acct.getId();
        myRef.child("tutor").child(id).child("Hire Request").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for(DataSnapshot newSnap : dataSnapshot.getChildren()) {
                    if(!newSnap.child("imgURL").getValue(String.class).equals("NO URL")) {
                        t = new Tutor(newSnap.child("Name").getValue(String.class), newSnap.getKey().toString(), newSnap.child("Email").getValue(String.class), newSnap.child("imgURL").getValue(String.class));
                        tList.add(t);
                    } else {
                        t = new Tutor(newSnap.child("Name").getValue(String.class), newSnap.getKey().toString(), newSnap.child("Email").getValue(String.class), "https://picsum.photos/500/500/?random");
                        tList.add(t);
                    }
                }
                tAdapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    public void srchData(final String query) {
        RecyclerView recycler2View;
        final TutorAdapter t2Adapter;           // customize class
        final List<Tutor> t2List = new ArrayList<>();
        recycler2View = (RecyclerView) findViewById(R.id.trv);
//        s2Adapter = new MyAdapter(s2List);
        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getApplicationContext());
        recycler2View.setLayoutManager(mLayoutManager);
        t2Adapter = new TutorAdapter(this,t2List,new CustomItemClickListener() {
            @Override
            public void onItemClick(View v, int position) {

                // do what ever you want to do with it
                String subject = t2List.get(position).getSubject();
                String name = t2List.get(position).getName();
                String id = t2List.get(position).getId();
//                Intent myIntent = new Intent(TutorHome.this,StudentDetails.class);
//                myIntent.putExtra("Tutor Id",id);
//                startActivity(myIntent);
            }
        });
        recycler2View.setAdapter(t2Adapter);
        myRef.child("Student").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for(DataSnapshot newSnap : dataSnapshot.getChildren()) {
                    if(newSnap.child("Name").getValue(String.class).equals(query)) {
                        if(!newSnap.child("imgURL").getValue(String.class).equals("NO URL")) {
                            t = new Tutor(newSnap.child("Subject").getValue(String.class), newSnap.getKey().toString(), newSnap.child("Name").getValue(String.class), newSnap.child("imgURL").getValue(String.class));
                            tList.add(t);
                        } else {
                            t = new Tutor(newSnap.child("Subject").getValue(String.class), newSnap.getKey().toString(), newSnap.child("Name").getValue(String.class), "https://picsum.photos/500/500/?random");
                            tList.add(t);
                        }
                    }

                }
                t2Adapter.notifyDataSetChanged();

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }




    private void revokeAccess() {
//         Firebase sign out
//        mAuth.signOut();

//        Delete data from firebase
        GoogleSignInAccount acct = GoogleSignIn.getLastSignedInAccount(this);
        final String id = acct.getId();



        // Google revoke access
        mGoogleSignInClient.revokeAccess().addOnCompleteListener(this,
                new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        myRef.child("tutor").child(id).removeValue();
                        Intent newIntent = new Intent(TutorHome.this, Main3Activity.class);
                        startActivity(newIntent);
                    }
                });
    }

    private void signOut() {
        // Firebase sign out
//        mAuth.signOut();

        // Google sign out
        mGoogleSignInClient.signOut().addOnCompleteListener(this,
                new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        Intent newIntent = new Intent(TutorHome.this, Main3Activity.class);
                        startActivity(newIntent);
                    }
                });
    }
}
