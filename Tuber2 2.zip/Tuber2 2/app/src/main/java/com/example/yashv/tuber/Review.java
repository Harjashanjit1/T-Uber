package com.example.yashv.tuber;

public class Review {
    // you can declare this as private and provide setter/getter
    public String review;
    public String name;


    public Review(String name, String review) {
        this.name = name;
        this.review = review;
    }

}
