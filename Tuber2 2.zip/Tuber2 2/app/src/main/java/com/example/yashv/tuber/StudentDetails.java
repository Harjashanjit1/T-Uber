package com.example.yashv.tuber;

import android.content.Intent;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;

import static android.view.View.GONE;

public class StudentDetails extends AppCompatActivity {

    FirebaseDatabase database = FirebaseDatabase.getInstance();
    DatabaseReference myRef = database.getReference("User");
    GoogleSignInClient mGoogleSignInClient;
    private RecyclerView recyclerView;
    private ReviewAdapter rAdapter;           // customize class
    private List<Review> rList = new ArrayList<>();
    Review r;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_details);
        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestEmail()
                .build();
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setLogo(R.drawable.logo);
        getSupportActionBar().setDisplayUseLogoEnabled(true);
        mGoogleSignInClient = GoogleSignIn.getClient(this, gso);
        Button acceptRequest = (Button) findViewById(R.id.btnAcceptRequest);

        acceptRequest.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                acceptRequest();
            }
        });
        ImageButton btnHome = (ImageButton) findViewById(R.id.btnHomeStudentDetails);
        btnHome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent newIntent = new Intent(StudentDetails.this,TutorHome.class);
                startActivity(newIntent);
            }
        });

        ImageButton btnProfile = (ImageButton) findViewById(R.id.btnProfileStudentDetails);
        btnProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent newIntent = new Intent(StudentDetails.this,TutorAccount.class);
                startActivity(newIntent);
            }
        });
    }

    @Override
    public void onStart() {
        super.onStart();
        GoogleSignInAccount acct = GoogleSignIn.getLastSignedInAccount(this);
        final String tutorId = acct.getId();
        Intent myIntent = getIntent();
        final String studentId = myIntent.getStringExtra("Student Id");

        myRef.child("tutor").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if(dataSnapshot.child(tutorId).hasChild("Hire Request")) {
                    if(dataSnapshot.child(tutorId).child("Hire Request").hasChild(studentId)) {
                        onLoad();
                    } else {
                        Intent newIntent = new Intent(StudentDetails.this,TutorHome.class);
                        startActivity(newIntent);
                    }
                } else {
                    Intent newIntent = new Intent(StudentDetails.this,TutorHome.class);
                    startActivity(newIntent);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });


    }

    public void onLoad() {
        recyclerView = (RecyclerView) findViewById(R.id.rvReviewS);
//            sAdapter = new MyAdapter(sList);
        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getApplicationContext());
        recyclerView.setLayoutManager(mLayoutManager);
        rAdapter = new ReviewAdapter(rList);
        recyclerView.setAdapter(rAdapter);
        getTheData();
    }

    private void getTheData() {

        Intent myIntent = getIntent();
        final String studentId = myIntent.getStringExtra("Student Id");

        myRef.child("Student").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for(DataSnapshot newSnap : dataSnapshot.child(studentId).child("Reviews").getChildren()) {

                    r = new Review(newSnap.child("Name").getValue(String.class),newSnap.child("Review").getValue(String.class));
                    rList.add(r);
                }
                rAdapter.notifyDataSetChanged();
                displayOtherData();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });




    }

    public void displayOtherData() {
        final ImageView studentImg = (ImageView) findViewById(R.id.imgStudentDetails);
        final TextView studentName = (TextView) findViewById(R.id.txtStudentDetailsName);
        final TextView studentEmail = (TextView) findViewById(R.id.txtStudentDetailsEmail);
        final TextView studentPhone = (TextView) findViewById(R.id.txtPhoneStudentDetails);
        final TextView studentEdu = (TextView) findViewById(R.id.txtEducStudentDetails);
        final TextView studentAge = (TextView) findViewById(R.id.txtAgeStudentDetails);

        Intent myIntent = getIntent();
        final String studentId = myIntent.getStringExtra("Student Id");

        myRef.child("Student").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                String student1Name = dataSnapshot.child(studentId).child("Name").getValue(String.class);
                String student1Phone = dataSnapshot.child(studentId).child("Phone").getValue(String.class);
                String student1Age = dataSnapshot.child(studentId).child("Age").getValue(String.class);
                String student1Edu = dataSnapshot.child(studentId).child("Education").getValue(String.class);
                String student1Email = dataSnapshot.child(studentId).child("Email").getValue(String.class);
                String studentImgUrl = dataSnapshot.child(studentId).child("imgURL").getValue(String.class);



                    studentName.setText(student1Name);
                    studentEmail.setText(student1Email);
                    studentPhone.setText(student1Phone);
                    studentEdu.setText(student1Edu);
                    studentAge.setText(student1Age);



                if(!studentImgUrl.equals("NO URL")) {
                    Picasso.get().load(studentImgUrl).into(studentImg);
                } else {
                    Picasso.get().load("https://picsum.photos/500/500/?random").into(studentImg);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    public  void acceptRequest() {
        Intent myIntent = getIntent();
        final String studentId = myIntent.getStringExtra("Student Id");
        final String studentName = myIntent.getStringExtra("Student Name");
        final String studentEmail = myIntent.getStringExtra("Student Email");
        GoogleSignInAccount acct = GoogleSignIn.getLastSignedInAccount(this);

        try {
            final String tutorId = acct.getId();
            String tutorName = acct.getDisplayName();
            String tutorEmail = acct.getEmail();


            myRef.child("Transactions").child(tutorId+studentId).child("Tutor Name").setValue(tutorName);
            myRef.child("Transactions").child(tutorId+studentId).child("Tutor Id").setValue(tutorId);
            myRef.child("Transactions").child(tutorId+studentId).child("Student Id").setValue(studentId);
            myRef.child("Transactions").child(tutorId+studentId).child("Tutor Email").setValue(tutorEmail);
            myRef.child("Transactions").child(tutorId+studentId).child("Student Name").setValue(studentName);
            myRef.child("Transactions").child(tutorId+studentId).child("Student Email").setValue(studentEmail);
            myRef.child("Transactions").child(tutorId+studentId).child("Transaction completed").setValue("false");
            myRef.child("Transactions").child(tutorId+studentId).child("Problem").setValue("false");

            Intent newIntent = new Intent(StudentDetails.this,TutorHome.class);
            startActivity(newIntent);

//            myRef.child("tutor").addValueEventListener(new ValueEventListener() {
//                @Override
//                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
//                    double lat = dataSnapshot.child(tutorId).child("Hire Request").child(studentId).child("Lat").getValue(Double.class);
//                    double longi = dataSnapshot.child(tutorId).child("Hire Request").child(studentId).child("Long").getValue(Double.class);
//                    Toast.makeText(StudentDetails.this, "Lat: "+lat+" Long: "+longi+"ID: "+tutorId,
//                            Toast.LENGTH_SHORT).show();
//                    Uri gmmIntentUri = Uri.parse("google.navigation:q="+lat+","+longi+"&mode=w");
//                    Intent mapIntent = new Intent(Intent.ACTION_VIEW, gmmIntentUri);
//                    mapIntent.setPackage("com.google.android.apps.maps");
//                    startActivity(mapIntent);
//
//                }
//
//                @Override
//                public void onCancelled(@NonNull DatabaseError databaseError) {
//
//                }
//            });



        }catch (NullPointerException e) {
            final String tutorId = acct.getId();

            String tutorEmail = acct.getEmail();
            myRef.child("Transactions").child(tutorId+studentId).child("Tutor Name").setValue(tutorEmail);
            myRef.child("Transactions").child(tutorId+studentId).child("Tutor Id").setValue(tutorId);
            myRef.child("Transactions").child(tutorId+studentId).child("Tutor Email").setValue(tutorEmail);
            myRef.child("Transactions").child(tutorId+studentId).child("Student Name").setValue(studentName);
            myRef.child("Transactions").child(tutorId+studentId).child("Student Email").setValue(studentEmail);
            myRef.child("Transactions").child(tutorId+studentId).child("Transaction completed").setValue("false");
            myRef.child("Transactions").child(tutorId+studentId).child("Problem").setValue("false");

            Intent newIntent = new Intent(StudentDetails.this,TutorHome.class);
            startActivity(newIntent);
//            myRef.child("tutor").addValueEventListener(new ValueEventListener() {
//                @Override
//                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
//                    double lat = dataSnapshot.child(tutorId).child("Hire Request").child(studentId).child("Lat").getValue(Double.class);
//                    double longi = dataSnapshot.child(tutorId).child("Hire Request").child(studentId).child("Long").getValue(Double.class);
//                    Toast.makeText(StudentDetails.this, "Lat: "+lat+" Long: "+longi+"ID: "+tutorId,
//                            Toast.LENGTH_SHORT).show();
////                    myRef.child("Transactions").child(tutorId+studentId).child("Student Lat").setValue(lat);
////                    myRef.child("Transactions").child(tutorId+studentId).child("Student Long").setValue(longi);
//                    Uri gmmIntentUri = Uri.parse("google.navigation:q="+lat+","+longi+"&mode=w");
//                    Intent mapIntent = new Intent(Intent.ACTION_VIEW, gmmIntentUri);
//                    mapIntent.setPackage("com.google.android.apps.maps");
//                    startActivity(mapIntent);
//
//
//                }
//
//                @Override
//                public void onCancelled(@NonNull DatabaseError databaseError) {
//
//                }
//            });


        }

    }
}
