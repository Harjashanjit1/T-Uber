package com.example.yashv.tuber;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;

import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class AllAvailableTutors extends AppCompatActivity {
    private RecyclerView recyclerView;
    private TutorAdapter tAdapter;           // customize class
    private List<Tutor> tList = new ArrayList<>();
    FirebaseDatabase database = FirebaseDatabase.getInstance();
    DatabaseReference myRef = database.getReference("User");
    GoogleSignInClient mGoogleSignInClient;
    Tutor t;
    String query;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_all_available_tutors);
        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestEmail()
                .build();
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setLogo(R.drawable.logo);
        getSupportActionBar().setDisplayUseLogoEnabled(true);
        mGoogleSignInClient = GoogleSignIn.getClient(this, gso);
        final EditText et = (EditText) findViewById(R.id.txtSrchAllTutor);
        ImageButton btnSrch = (ImageButton) findViewById(R.id.btnSrchAllTutor);

        btnSrch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                query = et.getText().toString();
                srchData(query);
            }
        });

        ImageButton btnHome = (ImageButton) findViewById(R.id.btnHomeAllTutor);
        btnHome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent myIntent = new Intent(AllAvailableTutors.this, StudentHome.class);

                startActivity(myIntent);
            }
        });

        ImageButton btnProfile = (ImageButton) findViewById(R.id.btnProfileAllTutor);
        btnProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent newIntent = new Intent(AllAvailableTutors.this,StudentAccount.class);
                startActivity(newIntent);
            }
        });
        ImageButton btnAllTutors = (ImageButton) findViewById(R.id.btnAllTutor);
        btnAllTutors.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent myIntent = getIntent();
                finish();
                startActivity(myIntent);
            }
            });
    }

    @Override
    public void onStart() {
        super.onStart();


        onLoad();


    }

    public void onLoad() {
        GoogleSignInAccount acct = GoogleSignIn.getLastSignedInAccount(this);
        final String studentId = acct.getId();

        recyclerView = (RecyclerView) findViewById(R.id.rvAllTutor);
//            sAdapter = new MyAdapter(sList);
        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getApplicationContext());
        recyclerView.setLayoutManager(mLayoutManager);
        tAdapter = new TutorAdapter(this,tList,new CustomItemClickListener() {
            @Override
            public void onItemClick(View v, int position) {

                // do what ever you want to do with it

                String subject = tList.get(position).getSubject();
                String name = tList.get(position).getName();
                final String id = tList.get(position).getId();
                myRef.child("tutor").addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                        if(dataSnapshot.child(id).hasChild("Hire Request")) {
                            if (dataSnapshot.child(id).child("Hire Request").hasChild(studentId)) {
                                Intent myIntent = new Intent(AllAvailableTutors.this, RequestSent.class);
                                myIntent.putExtra("Tutor Id", id);
                                startActivity(myIntent);
                            } else {
                                Intent myIntent = new Intent(AllAvailableTutors.this, TuterDetails.class);
                                myIntent.putExtra("Tutor Id", id);
                                startActivity(myIntent);
                            }
                        } else {
                            Intent myIntent = new Intent(AllAvailableTutors.this, TuterDetails.class);
                            myIntent.putExtra("Tutor Id", id);
                            startActivity(myIntent);
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });
            }
        });
        recyclerView.setAdapter(tAdapter);
        getTheData();
    }

    private void getTheData() {

        myRef.child("tutor").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for(DataSnapshot newSnap : dataSnapshot.getChildren()) {

                    if (newSnap.child("Available").getValue(String.class).equals("true")&&newSnap.child("Approved").getValue(String.class).equals("true")) {
                        if(!newSnap.child("imgURL").getValue(String.class).equals("NO URL")) {
                            t = new Tutor(newSnap.child("Subject").getValue(String.class), newSnap.getKey().toString(), newSnap.child("Name").getValue(String.class), newSnap.child("imgURL").getValue(String.class));
                            tList.add(t);
                        } else {
                            t = new Tutor(newSnap.child("Subject").getValue(String.class), newSnap.getKey().toString(), newSnap.child("Name").getValue(String.class), "https://picsum.photos/500/500/?random");
                            tList.add(t);
                        }
                    }
                }
                tAdapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });




    }

    public void srchData(final String query) {
        RecyclerView recycler2View;
        final TutorAdapter t2Adapter;           // customize class
        final List<Tutor> t2List = new ArrayList<>();
        recycler2View = (RecyclerView) findViewById(R.id.rvAllTutor);
//        s2Adapter = new MyAdapter(s2List);
        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getApplicationContext());
        recycler2View.setLayoutManager(mLayoutManager);
        t2Adapter = new TutorAdapter(this,t2List,new CustomItemClickListener() {
            @Override
            public void onItemClick(View v, int position) {

                // do what ever you want to do with it
                String subject = t2List.get(position).getSubject();
                String name = t2List.get(position).getName();
                String id = t2List.get(position).getId();
                Intent myIntent = new Intent(AllAvailableTutors.this,TuterDetails.class);
                myIntent.putExtra("Tutor Id",id);
                startActivity(myIntent);
            }
        });
        recycler2View.setAdapter(t2Adapter);
        final Intent subi = getIntent();
        final String sub = subi.getStringExtra("Subject");
        myRef.child("tutor").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for(DataSnapshot newSnap : dataSnapshot.getChildren()) {
                    if(newSnap.child("Name").getValue(String.class).equals(query)&&newSnap.child("Subject").getValue(String.class).equals(sub)&&newSnap.child("Available").getValue(String.class).equals("true")&&newSnap.child("Approved").getValue(String.class).equals("true")) {
                        t = new Tutor(newSnap.child("Subject").getValue(String.class),newSnap.getKey().toString(),newSnap.child("Name").getValue(String.class),newSnap.child("imgURL").getValue(String.class));
                        t2List.add(t);
                    }

                }
                t2Adapter.notifyDataSetChanged();

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }
}
