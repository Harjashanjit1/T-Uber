package com.example.yashv.tuber;

import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.util.List;

public class TutorAdapter extends RecyclerView.Adapter<TutorAdapter.MyViewHolder> {


    List<Tutor> tutorList;
    Context mContext;
    CustomItemClickListener listener;

    public class MyViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

        public TextView txtSubject, txtName, txtId;
        public ImageView imgTutorS;

        public MyViewHolder(View view) {
            super(view);

            txtSubject = (TextView) view.findViewById(R.id.txtSubject);
            txtName = (TextView) view.findViewById(R.id.txtName);
            txtId = (TextView) view.findViewById(R.id.txtId);
            imgTutorS = (ImageView) view.findViewById(R.id.imgTutorS);
            view.setOnClickListener(this);


            Log.d("MyViewHolder", "id"); // look at the console output
        }
        @Override
        public void onClick(View v) {
            listener.onItemClick(v, this.getAdapterPosition());
        }


    }

    public TutorAdapter(Context mContext, List<Tutor> tutorList, CustomItemClickListener listener) {
        this.tutorList = tutorList;
        this.mContext = mContext;
        this.listener = listener;
    }


    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.tutor_layout, parent, false);
        final TutorAdapter.MyViewHolder mViewHolder = new TutorAdapter.MyViewHolder(itemView);
        itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                listener.onItemClick(v, mViewHolder.getAdapterPosition());
            }
        });
        return new TutorAdapter.MyViewHolder(itemView);
    }
    public void onBindViewHolder(TutorAdapter.MyViewHolder holder, int position) {
        Tutor emp = tutorList.get(position);

        holder.txtSubject.setText("Speciality: "+emp.subject);
        holder.txtName.setText("Name: "+emp.name);
        holder.txtId.setText(emp.id);
        Picasso.get().load(emp.url).into(holder.imgTutorS);




    }


    @Override
    public int getItemCount() {
        return tutorList.size();
    }
}
