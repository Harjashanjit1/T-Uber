package com.example.yashv.tuber;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class Tutor extends AppCompatActivity {

    public String subject;
    public String id;
    public String name;
    public String url;


    public Tutor(String subject, String id, String name, String url) {
        this.subject = subject;
        this.id = id;
        this.name = name;
        this.url = url;
    }
    public String getSubject() {
        return subject;
    }
    public String getId() {
        return id;
    }
    public String getName() {
        return name;
    }
    public String getUrl() {
        return url;
    }
}
