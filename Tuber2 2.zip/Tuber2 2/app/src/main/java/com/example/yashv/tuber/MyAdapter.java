package com.example.yashv.tuber;

import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.List;

public class MyAdapter extends RecyclerView.Adapter<MyAdapter.MyViewHolder> {

    List<Subject> subjectList;
    Context mContext;
    CustomItemClickListener listener;

    public class MyViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

        public TextView txtSub;

        public MyViewHolder(View view) {
            super(view);

            txtSub = (TextView) view.findViewById(R.id.txtSub);
            view.setOnClickListener(this);


            Log.d("MyViewHolder", "id"); // look at the console output
        }
        @Override
        public void onClick(View v) {
            listener.onItemClick(v, this.getAdapterPosition());
        }


    }

    public MyAdapter (List<Subject> subjectList) {
        this.subjectList = subjectList;
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.sub_layout, parent, false);
        final MyViewHolder mViewHolder = new MyViewHolder(itemView);
        itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                listener.onItemClick(v, mViewHolder.getAdapterPosition());
            }
        });
        return new MyViewHolder(itemView);
    }
    public void onBindViewHolder(MyViewHolder holder, int position) {
        Subject emp = subjectList.get(position);

        holder.txtSub.setText(emp.subject);




    }
    @Override
    public int getItemCount() {
        return subjectList.size();
    }
    public MyAdapter(Context mContext, List<Subject> subjectList, CustomItemClickListener listener) {
        this.subjectList = subjectList;
        this.mContext = mContext;
        this.listener = listener;
    }
}
