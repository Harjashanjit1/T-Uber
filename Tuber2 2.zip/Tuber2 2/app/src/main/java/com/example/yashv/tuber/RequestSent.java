package com.example.yashv.tuber;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

public class RequestSent extends AppCompatActivity {

    FirebaseDatabase database = FirebaseDatabase.getInstance();
    DatabaseReference myRef = database.getReference("User");
    GoogleSignInClient mGoogleSignInClient;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_request_sent);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setLogo(R.drawable.logo);
        getSupportActionBar().setDisplayUseLogoEnabled(true);
        ImageButton btnHome = (ImageButton) findViewById(R.id.btnHomeSAccountR);
        btnHome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent newIntent = new Intent(RequestSent.this,StudentHome.class);
                startActivity(newIntent);
            }
        });
        ImageButton btnProfile = (ImageButton) findViewById(R.id.btnAllStudentAccountR);
        btnProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent newIntent = new Intent(RequestSent.this,AllAvailableTutors.class);
                startActivity(newIntent);
            }
        });
        ImageButton btnAllTutors = (ImageButton) findViewById(R.id.btnProfileSAccountR);
        btnAllTutors.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent newIntent = new Intent(RequestSent.this,StudentAccount.class);
                startActivity(newIntent);
            }
        });


        Button submit = (Button) findViewById(R.id.btRSubmit);
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                submitReview();

            }
        });
    }

    @Override

    public void onStart() {
        super.onStart();




        final ImageView tutorImg = (ImageView) findViewById(R.id.imgTutorDetailsR);
        final TextView tutorName = (TextView) findViewById(R.id.txtTuterDetailsNameR);
        final TextView tutorMsg = (TextView) findViewById(R.id.txtMsgR);
        final TextView studentMsg = (TextView) findViewById(R.id.txtRHead);
        final TextView tutorEmail = (TextView) findViewById(R.id.txtTuterDetailsEmailR);
        final TextView tutorSpecial = (TextView) findViewById(R.id.txtSpclR);
        final TextView tutorEdu = (TextView) findViewById(R.id.txtEducR);
        final TextView tutorAge = (TextView) findViewById(R.id.txtAgeTR);
        Intent myIntent = getIntent();
        final String tutorId = myIntent.getStringExtra("Tutor Id");
        GoogleSignInAccount acct = GoogleSignIn.getLastSignedInAccount(this);
        final String studentId = acct.getId();
//        LinearLayout llRV = (LinearLayout) findViewById(R.id.llReviewS);
//        llRV.setVisibility(View.GONE);


        myRef.child("tutor").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                String tutor1Name = dataSnapshot.child(tutorId).child("Name").getValue(String.class);
                String tutor1Special = dataSnapshot.child(tutorId).child("Speciality").getValue(String.class);
                String tutor1Education = dataSnapshot.child(tutorId).child("Education").getValue(String.class);
                String tutor1Age= dataSnapshot.child(tutorId).child("Age").getValue(String.class);
                String tutor1Email = dataSnapshot.child(tutorId).child("Email").getValue(String.class);
                String tutorImgUrl = dataSnapshot.child(tutorId).child("imgURL").getValue(String.class);
                String studentName = dataSnapshot.child(tutorId).child("Hire Request").child(studentId).child("Name").getValue(String.class);



                tutorName.setText(tutor1Name);
                tutorEmail.setText(tutor1Email);
                tutorSpecial.setText("Speciality: "+tutor1Special);
                tutorEdu.setText("Qualification: "+tutor1Education);
                tutorAge.setText("Age: "+tutor1Age);
                tutorMsg.setText("Your request to "+tutor1Name+" has been sent.");
                studentMsg.setText("Hi "+studentName);



                if(!tutorImgUrl.equals("NO URL")) {
                    Picasso.get().load(tutorImgUrl).into(tutorImg);
                } else {
                    Picasso.get().load("https://picsum.photos/500/500/?random").into(tutorImg);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });


    }



    public void submitReview() {
        final EditText review = (EditText) findViewById(R.id.etReview);
        final String msg = review.getText().toString();
        Intent myIntent = getIntent();
        final String tutorId = myIntent.getStringExtra("Tutor Id");
        GoogleSignInAccount acct = GoogleSignIn.getLastSignedInAccount(this);
        final String studentId = acct.getId();

        myRef.child("Student").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                String Name = dataSnapshot.child(studentId).child("Name").getValue(String.class);
                myRef.child("tutor").child(tutorId).child("Reviews").child(studentId).child("Review").setValue(msg);
                myRef.child("tutor").child(tutorId).child("Reviews").child(studentId).child("Name").setValue(Name);
                Toast.makeText(RequestSent.this, "Review has been submitted",
                        Toast.LENGTH_SHORT).show();
                Intent newIntent = getIntent();
                finish();
                startActivity(newIntent);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

    }
}
