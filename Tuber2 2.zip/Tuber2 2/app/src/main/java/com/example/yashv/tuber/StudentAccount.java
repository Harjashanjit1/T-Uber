package com.example.yashv.tuber;

import android.content.Intent;
import android.media.Image;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

public class StudentAccount extends AppCompatActivity {
    GoogleSignInClient mGoogleSignInClient;
    FirebaseDatabase database = FirebaseDatabase.getInstance();
    DatabaseReference myRef = database.getReference("User");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_account);
        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestEmail()
                .build();
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setLogo(R.drawable.logo);
        getSupportActionBar().setDisplayUseLogoEnabled(true);
        mGoogleSignInClient = GoogleSignIn.getClient(this, gso);
        final ImageView profilePic = (ImageView) findViewById(R.id.imgStudentProfile);
        final TextView name = (TextView) findViewById(R.id.txtStudentAccount);
        final TextView email = (TextView) findViewById(R.id.txtStudentEmail);
        GoogleSignInAccount acct = GoogleSignIn.getLastSignedInAccount(this);
        String id = acct.getId();
        myRef.child("Student").child(id).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if(!dataSnapshot.child("imgURL").getValue(String.class).equals("NO URL")) {
                    Picasso.get().load(dataSnapshot.child("imgURL").getValue(String.class)).into(profilePic);
                } else {
                    Picasso.get().load("https://picsum.photos/500/500/?random").into(profilePic);
                }

                if(!dataSnapshot.child("Name").getValue(String.class).equals(dataSnapshot.child("Email").getValue(String.class))) {
                    name.setText(dataSnapshot.child("Name").getValue(String.class));
                } else {
                    name.setVisibility(View.GONE);
                }
                email.setText(dataSnapshot.child("Email").getValue(String.class));
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });



        clicksHandler();

    }



    public void clicksHandler ()
    {
        ImageButton home = (ImageButton) findViewById(R.id.btnHomeSAccount);
        Button delete = (Button) findViewById(R.id.btnSADelete);
        Button logOut = (Button) findViewById(R.id.btnSALogout);
        Button switchA = (Button) findViewById(R.id.btnSASwitch);
        ImageButton allTutors = (ImageButton) findViewById(R.id.btnAllStudentAccount);
        ImageButton profile = (ImageButton) findViewById(R.id.btnProfileSAccount);
        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent myIntent = new Intent(StudentAccount.this, StudentHome.class);
                startActivity(myIntent);
            }
        });
        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                revokeAccess();
            }
        });

        logOut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                signOut();
            }
        });
        switchA.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                switchAccount();
            }
        });
        allTutors.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent newIntent = new Intent(StudentAccount.this,AllAvailableTutors.class);
                startActivity(newIntent);
            }
        });
        profile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent myIntent = getIntent();
                finish();
                startActivity(myIntent);
            }
        });

    }

    private void revokeAccess() {
//         Firebase sign out
//        mAuth.signOut();

//        Delete data from firebase
        GoogleSignInAccount acct = GoogleSignIn.getLastSignedInAccount(this);

        final String id = acct.getId();


        // Google revoke access
        mGoogleSignInClient.revokeAccess().addOnCompleteListener(this,
                new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        myRef.child("Student").child(id).removeValue();
                        Intent newIntent = new Intent(StudentAccount.this, MainActivity.class);
                        startActivity(newIntent);
                    }
                });
    }

    private void signOut() {
        // Firebase sign out
//        mAuth.signOut();

        // Google sign out
        mGoogleSignInClient.signOut().addOnCompleteListener(this,
                new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        Intent newIntent = new Intent(StudentAccount.this, MainActivity.class);
                        startActivity(newIntent);
                    }
                });
    }

    private void switchAccount() {
        GoogleSignInAccount acct = GoogleSignIn.getLastSignedInAccount(this);
        final String id = acct.getId();

        myRef.child("tutor").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if(dataSnapshot.hasChild(id)) {
                    Intent myIntent = new Intent(StudentAccount.this,TutorHome.class);
                    startActivity(myIntent);
                }
                else {
                    Intent myIntent = new Intent(StudentAccount.this,AdditionalUserData.class);
                    startActivity(myIntent);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }
}
