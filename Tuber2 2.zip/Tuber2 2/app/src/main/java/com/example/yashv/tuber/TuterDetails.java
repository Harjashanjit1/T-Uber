package com.example.yashv.tuber;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;

import static android.view.View.GONE;

public class TuterDetails extends AppCompatActivity implements LocationListener {

    FirebaseDatabase database = FirebaseDatabase.getInstance();
    DatabaseReference myRef = database.getReference("User");
    GoogleSignInClient mGoogleSignInClient;
    LocationManager locationManager;
    double longitude;
    double latitude;
    private RecyclerView recyclerView;
    private ReviewAdapter rAdapter;           // customize class
    private List<Review> rList = new ArrayList<>();
    Review r;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tuter_details);

        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestEmail()
                .build();
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setLogo(R.drawable.logo);
        getSupportActionBar().setDisplayUseLogoEnabled(true);
        mGoogleSignInClient = GoogleSignIn.getClient(this, gso);



        ImageButton btnHome = (ImageButton) findViewById(R.id.btnHomeTuterDetails);
        btnHome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent newIntent = new Intent(TuterDetails.this,StudentHome.class);
                startActivity(newIntent);
            }
        });
        ImageButton btnProfile = (ImageButton) findViewById(R.id.btnProfileTuterDetails);
        btnProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent newIntent = new Intent(TuterDetails.this,StudentAccount.class);
                startActivity(newIntent);
            }
        });
        ImageButton btnAllTutors = (ImageButton) findViewById(R.id.btnAllTuterDetails);
        btnAllTutors.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent newIntent = new Intent(TuterDetails.this,AllAvailableTutors.class);
                startActivity(newIntent);
            }
        });
        if (ContextCompat.checkSelfPermission(getApplicationContext(), android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(getApplicationContext(), android.Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {

            ActivityCompat.requestPermissions(this, new String[]{android.Manifest.permission.ACCESS_FINE_LOCATION, android.Manifest.permission.ACCESS_COARSE_LOCATION}, 101);

        }

        getLocation();

    }




    public void onLoad() {
        recyclerView = (RecyclerView) findViewById(R.id.rvReviewT);
//            sAdapter = new MyAdapter(sList);
        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getApplicationContext());
        recyclerView.setLayoutManager(mLayoutManager);
        rAdapter = new ReviewAdapter(rList);
        recyclerView.setAdapter(rAdapter);
        getTheData();
    }

    private void getTheData() {

        Intent myIntent = getIntent();
        final String tutorId = myIntent.getStringExtra("Tutor Id");

        myRef.child("tutor").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for(DataSnapshot newSnap : dataSnapshot.child(tutorId).child("Reviews").getChildren()) {

                    r = new Review(newSnap.child("Name").getValue(String.class),newSnap.child("Review").getValue(String.class));
                    rList.add(r);
                }
                rAdapter.notifyDataSetChanged();
                displayOtherData();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });




    }

    public void displayOtherData() {

        final ImageView tutorImg = (ImageView) findViewById(R.id.imgTutorDetails);
        final TextView tutorName = (TextView) findViewById(R.id.txtTuterDetailsName);
        final TextView tutorEmail = (TextView) findViewById(R.id.txtTuterDetailsEmail);
        final TextView tutorSpecial = (TextView) findViewById(R.id.txtSpcl);
        final TextView tutorEdu = (TextView) findViewById(R.id.txtEduc);
        final TextView tutorAge = (TextView) findViewById(R.id.txtAgeT);

        Intent myIntent = getIntent();
        final String tutorId = myIntent.getStringExtra("Tutor Id");

        myRef.child("tutor").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                String tutor1Name = dataSnapshot.child(tutorId).child("Name").getValue(String.class);
                String tutor1Special = dataSnapshot.child(tutorId).child("Speciality").getValue(String.class);
                String tutor1Education = dataSnapshot.child(tutorId).child("Education").getValue(String.class);
                String tutor1Age= dataSnapshot.child(tutorId).child("Age").getValue(String.class);
                String tutor1Email = dataSnapshot.child(tutorId).child("Email").getValue(String.class);
                String tutorImgUrl = dataSnapshot.child(tutorId).child("imgURL").getValue(String.class);



                tutorName.setText(tutor1Name);
                tutorEmail.setText(tutor1Email);
                tutorSpecial.setText("Speciality: "+tutor1Special);
                tutorEdu.setText("Qualification: "+tutor1Education);
                tutorAge.setText("Age: "+tutor1Age);



                if(!tutorImgUrl.equals("NO URL")) {
                    Picasso.get().load(tutorImgUrl).into(tutorImg);
                } else {
                    Picasso.get().load("https://picsum.photos/500/500/?random").into(tutorImg);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
        final Button hireTutor = (Button) findViewById(R.id.btnHireTuter);

        hireTutor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                hireTutor();
            }
        });
    }

    void getLocation() {
        try {
            locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
            locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 5000, 5, this);

            onLoad();


        }
        catch(SecurityException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onLocationChanged(Location location) {
        latitude = location.getLatitude();
        longitude = location.getLongitude();



//        try {
//            Geocoder geocoder = new Geocoder(this, Locale.getDefault());
//            List<Address> addresses = geocoder.getFromLocation(location.getLatitude(), location.getLongitude(), 1);
//            locationText.setText(locationText.getText() + "\n"+addresses.get(0).getAddressLine(0)+", "+
//                    addresses.get(0).getAddressLine(1)+", "+addresses.get(0).getAddressLine(2));
//        }catch(Exception e)
//        {
//
//        }

    }

    @Override
    public void onProviderDisabled(String provider) {
        Toast.makeText(TuterDetails.this, "Please Enable GPS and Internet", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {

    }

    @Override
    public void onProviderEnabled(String provider) {

    }

    public  void hireTutor() {
        Intent myIntent = getIntent();
        final String tutorId = myIntent.getStringExtra("Tutor Id");
        GoogleSignInAccount acct = GoogleSignIn.getLastSignedInAccount(this);
        Intent newIntent = new Intent(TuterDetails.this,Payment.class);
        newIntent.putExtra("Tutor Id", tutorId);
        newIntent.putExtra("Long",longitude);
        newIntent.putExtra("Lat",latitude);
        startActivity(newIntent);



    }
}
