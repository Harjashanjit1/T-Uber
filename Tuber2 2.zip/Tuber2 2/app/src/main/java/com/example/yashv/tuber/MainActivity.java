package com.example.yashv.tuber;

import android.content.Intent;
import android.net.Uri;
import android.nfc.Tag;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.SignInButton;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import com.facebook.FacebookSdk;
import com.facebook.appevents.AppEventsLogger;



public class MainActivity extends AppCompatActivity {

    long value;

    public static final String USER_NAME = "com.example.yashv.tuber.MESSAGE";
    GoogleSignInClient mGoogleSignInClient;
    private static int RC_SIGN_IN = 9001;


    private FirebaseAuth mAuth;
    final String TAG = "THIS IS THE TEST LOG";
    FirebaseDatabase database = FirebaseDatabase.getInstance();
    DatabaseReference myRef = database.getReference("User");


//    Firebase instance declaration

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        SignInButton signInButton = findViewById(R.id.sign_in_button);
        signInButton.setSize(SignInButton.SIZE_STANDARD);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setLogo(R.drawable.logo);
        getSupportActionBar().setDisplayUseLogoEnabled(true);










//        Firebase instance initialize

        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestEmail()
                .build();
        mAuth = FirebaseAuth.getInstance();

        mGoogleSignInClient = GoogleSignIn.getClient(this, gso);

        signInButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                switch (v.getId()) {
                    case R.id.sign_in_button:
                        signIn();
                        break;
                    // ...
                }
            }
        });








    }

//    Following function checks wheter the user is already signed in or not


    @Override
    public void onStart() {
        super.onStart();
        GoogleSignInAccount account = GoogleSignIn.getLastSignedInAccount(this);

        updateUIGOOGLE(account);



    }




//Google Sign In==================================================================================
    private void signIn() {
        Intent signInIntent = mGoogleSignInClient.getSignInIntent();
        startActivityForResult(signInIntent, RC_SIGN_IN);
    }



    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        // Result returned from launching the Intent from GoogleSignInClient.getSignInIntent(...);
        if (requestCode == RC_SIGN_IN) {
            // The Task returned from this call is always completed, no need to attach
            // a listener.
            Task<GoogleSignInAccount> task = GoogleSignIn.getSignedInAccountFromIntent(data);

            handleSignInResult(task);
        }
    }

    private void handleSignInResult(Task<GoogleSignInAccount> completedTask) {
        try {
            GoogleSignInAccount account = completedTask.getResult(ApiException.class);


            // Signed in successfully, show authenticated UI.
            updateUIGOOGLE(account);
        } catch (ApiException e) {
            // The ApiException status code indicates the detailed failure reason.
            // Please refer to the GoogleSignInStatusCodes class reference for more information.
//            Log.w(TAG, "signInResult:failed code=" + e.getStatusCode());
            Toast.makeText(MainActivity.this, "Not Connected to internet",
                    Toast.LENGTH_SHORT).show();
        }
    }
//Google Sign Out======================================================================================
//    private void signOut() {
        // Firebase sign out
//        mAuth.signOut();

        // Google sign out
//        mGoogleSignInClient.signOut().addOnCompleteListener(this,
//                new OnCompleteListener<Void>() {
//                    @Override
//                    public void onComplete(@NonNull Task<Void> task) {
//                        updateUIGOOGLE(null);
//                    }
//                });
//    }
//
//    private void revokeAccess() {
        // Firebase sign out
//        mAuth.signOut();

//        Delete data from firebase
//        GoogleSignInAccount acct = GoogleSignIn.getLastSignedInAccount(this);
//        String id = acct.getId();
//        myRef.child(id).removeValue();
//
//        // Google revoke access
//        mGoogleSignInClient.revokeAccess().addOnCompleteListener(this,
//                new OnCompleteListener<Void>() {
//                    @Override
//                    public void onComplete(@NonNull Task<Void> task) {
//                        updateUIGOOGLE(null);
//                    }
//                });
//    }

    public void updateUIGOOGLE(GoogleSignInAccount user) {

//        GoogleSignInAccount acct = GoogleSignIn.getLastSignedInAccount(this);



        if (user != null) {
            final String ID = user.getId();


            myRef.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                        Intent myIntent = new Intent(MainActivity.this, StudentOrTutor.class);
                        startActivity(myIntent);

                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            });

        }
        else if(user == null) {
            Toast.makeText(MainActivity.this, "You are logged out",
                    Toast.LENGTH_SHORT).show();

        }







    }


//    public void createTutor() {
//
//        GoogleSignInAccount acct = GoogleSignIn.getLastSignedInAccount(this);
//        String Name = acct.getDisplayName();
//        String Email = acct.getEmail();
//        String id = acct.getId();
//        String token = acct.getIdToken();
//        EditText ed = findViewById(R.id.txtSubject);
//        String Subject = ed.getText().toString();
//        String approved = "true";
//        String available = "true";
//
//        myRef.child(id).child("Name").setValue(Name);
//        myRef.child(id).child("Email").setValue(Email);
//        myRef.child(id).child("Subject").setValue(Subject);
//        myRef.child(id).child("Approved").setValue(approved);
//        myRef.child(id).child("Available").setValue(available);
//
//
//
//
//
//
//    }

//    public void tutorNext() {
//
//        GoogleSignInAccount acct = GoogleSignIn.getLastSignedInAccount(this);
//        final String id = acct.getId();
//
//
//        myRef.child(id).addValueEventListener(new ValueEventListener() {
//            @Override
//            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
//
//                 if(dataSnapshot.hasChild("Subject")) {
//                     Intent myIntent = new Intent(MainActivity.this, Main4Activity.class);
//                     startActivity(myIntent);
//                 }
//                 else {
//
//                 }
//            }
//
//            @Override
//            public void onCancelled(@NonNull DatabaseError databaseError) {
//
//            }
//        });
//
//
//
//
//
//
//
////        else {
////            Intent myIntent = new Intent(MainActivity.this, Main2Activity.class);
////            startActivity(myIntent);
////        }
//    }











}




//Extra Code===================================================================================================


//        Button btn = findViewById(R.id.btnSignup);
//        Button btn2 = findViewById(R.id.btnLogin);
//        final TextView tv = findViewById(R.id.txt2Test);
//        Button btn2 = findViewById(R.id.btn2Test);

//        btn.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//
//
//                EditText em = findViewById(R.id.txtEmail);
//
//                String email = em.getText().toString();
//
//                EditText pw = findViewById(R.id.txtPswd);
//                String password = pw.getText().toString();
//
//
//                signup(email, password);
//
//
//
//
//
//
//
//
//            }});
//        btn2.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//
//                EditText em = findViewById(R.id.txtEmail);
//
//                String email = em.getText().toString();
//
//                EditText pw = findViewById(R.id.txtPswd);
//                String password = pw.getText().toString();
//
//                login(email, password);
//
//
//
//
//
//
//            }});

//    @Override
//    public void onStart() {
//        super.onStart();
//        FirebaseUser currentUser = mAuth.getCurrentUser();
//
//        updateUI(currentUser);
//
//
//
//    }

//    public void signup(String email, String password) {
//        mAuth.createUserWithEmailAndPassword(email, password)
//                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
//                    @Override
//                    public void onComplete(@NonNull Task<AuthResult> task) {
//                        if (task.isSuccessful()) {
//                            // Sign in success, update UI with the signed-in user's information
//                            Log.d(TAG, "createUserWithEmail:success");
//                            FirebaseUser user = mAuth.getCurrentUser();
//                            updateUI(user);
//                        } else {
//                            // If sign in fails, display a message to the user.
//                            Log.w(TAG, "createUserWithEmail:failure", task.getException());
//                            Toast.makeText(MainActivity.this, "Authentication failed.",
//                                    Toast.LENGTH_SHORT).show();
//                            updateUI(null);
//                        }
//
//                        // ...
//                    }
//                });
//    }

//    public void login(String email, String password) {
//        mAuth.signInWithEmailAndPassword(email, password)
//                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
//                    @Override
//                    public void onComplete(@NonNull Task<AuthResult> task) {
//                        if (task.isSuccessful()) {
//                            // Sign in success, update UI with the signed-in user's information
//                            Log.d(TAG, "signInWithEmail:success");
//                            FirebaseUser user = mAuth.getCurrentUser();
//                            updateUI(user);
//                        } else {
//                            // If sign in fails, display a message to the user.
//                            Log.w(TAG, "signInWithEmail:failure", task.getException());
//                            Toast.makeText(MainActivity.this, "Authentication failed.",
//                                    Toast.LENGTH_SHORT).show();
//                            updateUI(null);
//                        }
//
//                        // ...
//                    }
//                });
//    }

//    public void updateUI(FirebaseUser user) {
//
//        TextView tv = findViewById(R.id.txtName);
//        TextView tv2 = findViewById(R.id.txtEmail);
//
//        if(user!=null) {
//
//            Intent myIntent = new Intent(MainActivity.this, Main2Activity.class);
//            myIntent.putExtra(USER_NAME,user.getEmail());
//
//            startActivity(myIntent);
//        }
//
//    }


//===========================================================================================================


//        btn.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                myRef.child("Test123").setValue("This is a test");
//                myRef.child("Test123").addValueEventListener(new ValueEventListener() {
//                    @Override
//                    public void onDataChange(DataSnapshot dataSnapshot) {
//                        String value = dataSnapshot.getValue(String.class);
//                        tv.setText(value);
//                    }
//
//                    @Override
//                    public void onCancelled(DatabaseError databaseError) {
//                        myRef.addValueEventListener(new ValueEventListener() {
//                            @Override
//                            public void onDataChange(DataSnapshot dataSnapshot) {
//                                String value = dataSnapshot.getValue(String.class);
//                                Log.d(TAG, "Value is:" + value);
//                            }
//
//                            @Override
//                            public void onCancelled(DatabaseError databaseError) {
//
//                            }
//                        });
//                    }
//                });
//            }

//Manipulation with firebase data===============================================================

//    Button disp = findViewById(R.id.btnDisp);
//
//        disp.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//
//                display();
//            }
//        });

//    public void display() {
//
//
//
//
//
//        GoogleSignInAccount acct = GoogleSignIn.getLastSignedInAccount(this);
//        String id = acct.getId();
//        final TextView tv = findViewById(R.id.txtTest);
//
//        myRef.addValueEventListener(new ValueEventListener() {
//            @Override
//            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
//                for(DataSnapshot newsnap: dataSnapshot.getChildren()) {
//
//
//
//
//                    if( newsnap.getKey().equals("3")) {
//                        tv.append("test");
//                    }
//
//                }
//            }
//
//            @Override
//            public void onCancelled(@NonNull DatabaseError databaseError) {
//
//            }
//        });
//
//
//
//    }


//        signOutButton.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//
//                signOut();
//            }
//        });

//        deleteAccoutButton.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                revokeAccess();
//            }
//        });

//    Button tutor = findViewById(R.id.btnTutor);
//        tutor.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//
//
//                tutorNext();
//            }
//        });
//        Button complete = findViewById(R.id.btnComplete);
//        complete.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                createTutor();
//            }
//        });